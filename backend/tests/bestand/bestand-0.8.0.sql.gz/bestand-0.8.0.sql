BEGIN TRANSACTION;
CREATE TABLE accounts (
	id INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	display_name VARCHAR(80) NOT NULL, 
	whats_new_seen VARCHAR(32) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	sign_in VARCHAR(16) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	email_source VARCHAR(16) NOT NULL, 
	email_confirmed VARCHAR(255) NOT NULL, 
	email_pending VARCHAR(255) NOT NULL, 
	email_pending_hash VARCHAR(64) NOT NULL, 
	email_pending_until DATETIME, 
	language VARCHAR(16) NOT NULL, 
	browser_language VARCHAR(16) NOT NULL, 
	timezone VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	failed_logins INTEGER NOT NULL, 
	locked_until DATETIME, 
	blocked_at DATETIME, 
	totp_secret_enc TEXT NOT NULL, 
	totp_recovery TEXT NOT NULL, 
	totp_last_step INTEGER NOT NULL, 
	avatar BLOB, 
	avatar_at DATETIME, 
	avatar_hash VARCHAR(64) NOT NULL, 
	preferences JSON, 
	device_key VARCHAR(64) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "accounts" VALUES(1,'betreiber','','0.8.0','operator','password','$argon2id$v=19$m=1024,t=1,p=1$YjJT4Chon5XLI8SVM8L7qg$6G/RAQV4cmkCLVJiA5kVb4mfR82dRBNHQb0csP16jOc','betrieb@example.com','own','betrieb@example.com','','',NULL,'de','','','2026-11-24 19:49:37.807633','2026-11-24 19:49:39.796410',0,NULL,NULL,'1bda62357aae9c8c7b146abcdf5d8960f533c710696aae554e91bd2864b60cc9679c4f4019775c8258920c23ad8abdea1fee7d8ca041a6eb1f61a37a','["e040b90f1e0f5c706886877aa3abb811d78a0fed0aa381fe13952b4c77cfe777", "381c34dec6252f79f06ea8273d17c4a85a2e6c0aa595192f48907ddc7a4ec97e", "225ab459f55927a79fcc600d3058e82eecad2cffdcc18e61a5f22f98164eda50", "2a5e403781cdb5812b9ed9586433420a055d672589e66ab4ea80e4a6da81f367", "2a4c4f2d20dc84e7e03149166c3883a75a2048d3697adce34271df46602790a5", "379af3e21e6d14548174f1609f3d8e32b6a8f721b8f93c26bc3930f0305f3062", "f871a43f9ff4bcdbf3f27dae62397746bee942cefe6a1c4c56bc20eb7931e545", "5a2c02e3e6f198429ff62e8c1ad828fc634068421bb29a1eb1b84deb38156c1f"]',59851659,NULL,NULL,'',NULL,'V32CkAVNBRgEyqAQQfY0Eg79G8j5nkCn');
INSERT INTO "accounts" VALUES(2,'anna','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$TSJoPRUEufzOeXEjOIYXEg$xTKn0ysumi3elPP+yUXSwHo0nbT7lpf/JbqSUF3fWcM','anna@example.com','own','anna@example.com','','',NULL,'','','','2026-11-24 19:49:38.878424','2026-11-24 19:49:38.895071',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'kTzLXZzGwCUAC0V82UvUvyTl8tsUV7T3');
INSERT INTO "accounts" VALUES(3,'ben','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$POJMlBboXKZcDa5iTXTc5w$8HSW/sKBtOtcmk7tLlitHWhlwyFUOYxdINE6hoPnzbU','ben@example.net','','','','',NULL,'','','','2026-11-24 19:49:39.000965','2026-11-24 19:49:39.022665',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'wn6NtNJL0NcQ492_a7rhjk1ruGjmRbgu');
INSERT INTO "accounts" VALUES(4,'carla','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$839MCsHz0dD9pmOdFzX7Bw$kpq+dgL9LtuaxjOdR9URWfNuu8OCT1vuQl6V0RMWGHs','familie@example.org','','','','',NULL,'','','','2026-11-24 19:49:39.067595','2026-11-24 19:49:39.080964',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'H-rDFlIk9llmt2rgwTy_iq8TSa6xn2L3');
INSERT INTO "accounts" VALUES(5,'dora','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$TBk1ivBbgA3zXnbmIxl/Qg$sdPvGra1WHRIb4wqfAMCDHIif4XkKKOiPAor6P3stvI','Familie@Example.org','own','Familie@Example.org','','',NULL,'','','','2026-11-24 19:49:39.117575','2026-11-24 19:49:39.133568',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'upYNbpfL5lENlwL6jk_F39qWMjTpHOH3');
INSERT INTO "accounts" VALUES(6,'emil','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$54ZcxQ4zDAaJaKLC1a/p1w$6ddOeVqWfWl7wUrA/AcLS3Lh8duZ8BlnN0cCnM5xhKg','','','','emil@example.com','500bfb1aa497dc52616d576bf946b9d41a98de00148f35a35cd7d5aa3bcd278b','2026-11-25 19:49:39.223851','','','','2026-11-24 19:49:39.194824','2026-11-24 19:49:39.210504',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'s9dI4QL3NgxTLjdW13nqTPU6ASyK4R4c');
INSERT INTO "accounts" VALUES(7,'fritz','','0.8.0','member','oidc','','fritz@example.com','provider','','','',NULL,'','','','2026-11-24 19:49:39.339680','2026-11-24 19:49:39.359299',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'IwcROVqEjJKa-ux7MBKojTTpoMFn4mwW');
INSERT INTO "accounts" VALUES(8,'greta','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$VZsDin02lj1150BmxyhU8Q$g1LIgE+GmqHuzFHMlcJ8NSIy2qtJiSYTUqZTGzSGhd4','greta@example.com','','','','',NULL,'','','','2026-11-24 19:49:39.402661','2026-11-24 19:49:39.441431',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'ba7PFN6MG9BP8i1mtiEnLZ3Uzkl_t8Le');
INSERT INTO "accounts" VALUES(9,'hans','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$AhB98j2y83giupdPSRyMbA$fwTehE7Ov1ANYxnPoISIoUex1bMVy2kYpWD71amozEw','hans@example.com','','','','',NULL,'','','','2026-11-24 19:49:39.579060','2026-11-24 19:49:39.593732',0,NULL,'2026-11-24 19:49:39.624308','','',0,NULL,NULL,'',NULL,'qFs6b50tO6NqyhcBe5sCR-EaMxo6VrSh');
INSERT INTO "accounts" VALUES(10,'jonas','','0.8.0','member','password','$argon2id$v=19$m=1024,t=1,p=1$iEbo0AEyeHmXbDKuzU+4ZQ$PUoL0lbZzAzGnZ6XnkPWRPLSHpFUAut9juQo/uXCnQA','','','','','',NULL,'','','','2026-11-24 19:49:39.669633','2026-11-24 19:49:39.683454',0,NULL,NULL,'','',0,NULL,NULL,'',NULL,'6oADL7jVeF3BYtxFsFM1w_MFrkDfKRgd');
CREATE TABLE api_tokens (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	spaces JSON, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	expires_at DATETIME, 
	blocked_at DATETIME, 
	warned_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "api_tokens" VALUES(1,2,'Skript','read','1c0063878264af1ef08d1c7fbd5c626cc334f666d9cc779253c0b5dec614dc9d','ntk_best','null','2026-11-24 19:49:38.967113',NULL,NULL,NULL,NULL);
CREATE TABLE app_devices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	key_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	push_ticket VARCHAR(1024) NOT NULL, 
	push_key VARCHAR(64) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (key_hash)
);
INSERT INTO "app_devices" VALUES(1,2,'iPhone von Anna','3a2a8c337ef8d01a67a5c0b598c24c8824c4429285c8ed44f01a22d1c20e19f4','2026-11-24 19:49:38.975133',NULL,'','');
CREATE TABLE app_ops (
	caller VARCHAR(24) NOT NULL, 
	op_id VARCHAR(64) NOT NULL, 
	result JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (caller, op_id)
);
CREATE TABLE app_pairings (
	id VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	secret_hash VARCHAR(64) NOT NULL, 
	code_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	device_name VARCHAR(80) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE attachments (
	id VARCHAR(36) NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	name VARCHAR(255) NOT NULL, 
	mime VARCHAR(255) NOT NULL, 
	size INTEGER NOT NULL, 
	hash VARCHAR(64) NOT NULL, 
	created_by INTEGER, 
	created_at VARCHAR(24) NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(reminder_id) REFERENCES reminders (id) ON DELETE CASCADE
);
CREATE TABLE auth_sessions (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	ip VARCHAR(64) NOT NULL, 
	user_agent VARCHAR(255) NOT NULL, 
	by_provider BOOLEAN DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "auth_sessions" VALUES(1,'1cc3134a49b58d30f6b770376e84f2f8390bf2f62bd42c39a02898a5c3109353',1,'2026-11-24 19:49:37.861113','2026-12-24 19:49:37.856068','2026-11-24 19:49:37.861119','198.51.100.10','testclient',0);
INSERT INTO "auth_sessions" VALUES(2,'5f6c3c0be3235c6696b47f6a7c20f2df0cf0ab3f0fa8166ec5db7b0d9b278349',2,'2026-11-24 19:49:38.897676','2026-12-24 19:49:38.894981','2026-11-24 19:49:38.897680','198.51.100.21','testclient',0);
INSERT INTO "auth_sessions" VALUES(3,'cfd81a6252aa0f5385ff06cafe88f9dfa59487301d461720e01894df73009b4a',3,'2026-11-24 19:49:39.025194','2026-12-24 19:49:39.022542','2026-11-24 19:49:39.025198','198.51.100.22','testclient',0);
INSERT INTO "auth_sessions" VALUES(4,'b592592b1c95b5cfc9c9b4a75ae96010343531ff287de44b90165e9815f9dfa5',4,'2026-11-24 19:49:39.083837','2026-12-24 19:49:39.080840','2026-11-24 19:49:39.083841','198.51.100.23','testclient',0);
INSERT INTO "auth_sessions" VALUES(5,'a1ec30755b6a449528278d2e71bc7ac39a3f259abcd35e0df5e04d42acc98b98',5,'2026-11-24 19:49:39.137658','2026-12-24 19:49:39.132902','2026-11-24 19:49:39.137664','198.51.100.24','testclient',0);
INSERT INTO "auth_sessions" VALUES(6,'28a1e7af894fef94fcb1f75d6acc274b3e5ed869f5712d716dcf7cf15f241752',6,'2026-11-24 19:49:39.213081','2026-12-24 19:49:39.210392','2026-11-24 19:49:39.213085','198.51.100.25','testclient',0);
INSERT INTO "auth_sessions" VALUES(7,'c0eafb0bf50fd93ad8ecca5685412cb5a8620c3deaf0e6a930b0c2acad8a55f5',7,'2026-11-24 19:49:39.362613','2026-12-24 19:49:39.359184','2026-11-24 19:49:39.362618','198.51.100.60','testclient',1);
INSERT INTO "auth_sessions" VALUES(8,'ed746963a73d1e95efe94a12d77ea7bb79c6320cff2f64712a0525e2f30e4df5',8,'2026-11-24 19:49:39.421411','2026-12-24 19:49:39.418542','2026-11-24 19:49:39.421416','198.51.100.27','testclient',0);
CREATE TABLE change_bundles (
	account_id INTEGER NOT NULL, 
	list_id VARCHAR(36) NOT NULL, 
	opened_at DATETIME NOT NULL, 
	events JSON NOT NULL, 
	PRIMARY KEY (account_id, list_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE comment_bundles (
	account_id INTEGER NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	opened_at DATETIME NOT NULL, 
	events JSON NOT NULL, 
	PRIMARY KEY (account_id, reminder_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE comments (
	id VARCHAR(36) NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	author_id INTEGER, 
	text TEXT NOT NULL, 
	mentions JSON NOT NULL, 
	attachment_id VARCHAR(36), 
	created_at VARCHAR(24) NOT NULL, 
	edited_at VARCHAR(24), 
	removed_at VARCHAR(24), 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(reminder_id) REFERENCES reminders (id) ON DELETE CASCADE
);
CREATE TABLE completions (
	id INTEGER NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	series_id VARCHAR(36), 
	space_id VARCHAR(36) NOT NULL, 
	list_id VARCHAR(36) NOT NULL, 
	section_id VARCHAR(36), 
	parent_id VARCHAR(36), 
	title VARCHAR(500) NOT NULL, 
	completed_at VARCHAR(24) NOT NULL, 
	completed_by INTEGER, 
	due_date VARCHAR(10), 
	due_time VARCHAR(5), 
	created_at VARCHAR(24), 
	on_time BOOLEAN, 
	logged_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (reminder_id)
);
CREATE TABLE cursor_times (
	cursor INTEGER NOT NULL, 
	at DATETIME NOT NULL, 
	PRIMARY KEY (cursor)
);
INSERT INTO "cursor_times" VALUES(1,'2026-11-24 19:49:37.838574');
INSERT INTO "cursor_times" VALUES(2,'2026-11-24 19:49:37.843009');
INSERT INTO "cursor_times" VALUES(3,'2026-11-24 19:49:37.849183');
INSERT INTO "cursor_times" VALUES(4,'2026-11-24 19:49:37.991030');
INSERT INTO "cursor_times" VALUES(5,'2026-11-24 19:49:37.995701');
INSERT INTO "cursor_times" VALUES(6,'2026-11-24 19:49:38.888145');
INSERT INTO "cursor_times" VALUES(7,'2026-11-24 19:49:38.889473');
INSERT INTO "cursor_times" VALUES(8,'2026-11-24 19:49:38.891270');
INSERT INTO "cursor_times" VALUES(9,'2026-11-24 19:49:38.951451');
INSERT INTO "cursor_times" VALUES(10,'2026-11-24 19:49:39.002990');
INSERT INTO "cursor_times" VALUES(11,'2026-11-24 19:49:39.015111');
INSERT INTO "cursor_times" VALUES(12,'2026-11-24 19:49:39.016394');
INSERT INTO "cursor_times" VALUES(13,'2026-11-24 19:49:39.018279');
INSERT INTO "cursor_times" VALUES(14,'2026-11-24 19:49:39.074364');
INSERT INTO "cursor_times" VALUES(15,'2026-11-24 19:49:39.075590');
INSERT INTO "cursor_times" VALUES(16,'2026-11-24 19:49:39.077176');
INSERT INTO "cursor_times" VALUES(17,'2026-11-24 19:49:39.124666');
INSERT INTO "cursor_times" VALUES(18,'2026-11-24 19:49:39.126193');
INSERT INTO "cursor_times" VALUES(19,'2026-11-24 19:49:39.128067');
INSERT INTO "cursor_times" VALUES(20,'2026-11-24 19:49:39.203071');
INSERT INTO "cursor_times" VALUES(21,'2026-11-24 19:49:39.204321');
INSERT INTO "cursor_times" VALUES(22,'2026-11-24 19:49:39.206237');
INSERT INTO "cursor_times" VALUES(23,'2026-11-24 19:49:39.352316');
INSERT INTO "cursor_times" VALUES(24,'2026-11-24 19:49:39.353704');
INSERT INTO "cursor_times" VALUES(25,'2026-11-24 19:49:39.355427');
INSERT INTO "cursor_times" VALUES(26,'2026-11-24 19:49:39.411148');
INSERT INTO "cursor_times" VALUES(27,'2026-11-24 19:49:39.412480');
INSERT INTO "cursor_times" VALUES(28,'2026-11-24 19:49:39.414428');
INSERT INTO "cursor_times" VALUES(29,'2026-11-24 19:49:39.587062');
INSERT INTO "cursor_times" VALUES(30,'2026-11-24 19:49:39.588261');
INSERT INTO "cursor_times" VALUES(31,'2026-11-24 19:49:39.589856');
INSERT INTO "cursor_times" VALUES(32,'2026-11-24 19:49:39.676673');
INSERT INTO "cursor_times" VALUES(33,'2026-11-24 19:49:39.677914');
INSERT INTO "cursor_times" VALUES(34,'2026-11-24 19:49:39.679536');
INSERT INTO "cursor_times" VALUES(35,'2026-11-24 19:49:39.766720');
INSERT INTO "cursor_times" VALUES(36,'2026-11-24 19:49:39.768069');
INSERT INTO "cursor_times" VALUES(37,'2026-11-24 19:49:39.769757');
INSERT INTO "cursor_times" VALUES(38,'2026-11-24 19:49:39.813935');
INSERT INTO "cursor_times" VALUES(39,'2026-11-24 19:49:39.816763');
CREATE TABLE external_refs (
	account_id INTEGER NOT NULL, 
	"key" VARCHAR(200) NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id, "key"), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(reminder_id) REFERENCES reminders (id) ON DELETE CASCADE
);
CREATE TABLE filters (
	id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	color VARCHAR(16) NOT NULL, 
	icon VARCHAR(64) NOT NULL, 
	position VARCHAR(200) NOT NULL, 
	rules JSON NOT NULL, 
	hidden BOOLEAN NOT NULL, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE focus (
	account_id INTEGER NOT NULL, 
	day VARCHAR(10) NOT NULL, 
	reminder_ids JSON NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE gone (
	kind VARCHAR(16) NOT NULL, 
	id VARCHAR(80) NOT NULL, 
	account_id INTEGER NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	gone_at DATETIME NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (kind, id, account_id)
);
INSERT INTO "gone" VALUES('space','59ce4062-7a34-4d3c-80c5-fa291b88f94c',0,'59ce4062-7a34-4d3c-80c5-fa291b88f94c','2026-11-24 19:49:39.814412',38);
INSERT INTO "gone" VALUES('list','bf16155e-5845-4625-addf-8d887d9ba9e2',0,'59ce4062-7a34-4d3c-80c5-fa291b88f94c','2026-11-24 19:49:39.816994',39);
CREATE TABLE hidden (
	account_id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	id VARCHAR(80) NOT NULL, 
	at DATETIME NOT NULL, 
	cursor INTEGER NOT NULL, 
	space_id VARCHAR(36), 
	PRIMARY KEY (account_id, kind, id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE invites (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	space_id VARCHAR(36), 
	email VARCHAR(255) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "invites" VALUES(1,'98a50b2f46b360f1c41428e36c502594ee267f7b774b04f13593172c869d8e8f',NULL,'neu@example.com',1,'2026-11-24 19:49:39.863187','2026-12-01 19:49:39.862861');
INSERT INTO "invites" VALUES(2,'ab4ec8d28c1fe452625032fdf714e9ffd6dc233b89a98523ce1e9933eb487356',NULL,'',1,'2026-11-24 19:49:39.880501','2026-12-01 19:49:39.878851');
INSERT INTO "invites" VALUES(3,'e1dd0a9b2257acd329689aaec273093a59e5f16e99ea4e136c58d9dc4c7f1ad6','d0561a4d-717b-4cc8-9008-dbd83309d638','',1,'2026-11-24 19:49:39.891393','2026-12-01 19:49:39.891119');
INSERT INTO "invites" VALUES(4,'944255563ef08623918169d48e93fd78fe494aad8d1f40f77ff6a400aafd63cd','d0561a4d-717b-4cc8-9008-dbd83309d638','gast@example.com',1,'2026-11-24 19:49:39.897048','2026-12-01 19:49:39.896820');
INSERT INTO "invites" VALUES(5,'08357524a04281eee8db7b86d9063b09b8244deb1a548cc70ce52aa9433c39e9','d0561a4d-717b-4cc8-9008-dbd83309d638','',1,'2026-11-24 19:49:39.903313','2026-12-01 19:49:39.902959');
CREATE TABLE list_prefs (
	account_id INTEGER NOT NULL, 
	list_id VARCHAR(36) NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	show_completed BOOLEAN NOT NULL, 
	notify_changes BOOLEAN NOT NULL, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (account_id, list_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(list_id) REFERENCES lists (id) ON DELETE CASCADE
);
CREATE TABLE lists (
	id VARCHAR(36) NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	color VARCHAR(16) NOT NULL, 
	icon VARCHAR(64) NOT NULL, 
	"view" VARCHAR(16) NOT NULL, 
	position VARCHAR(200) NOT NULL, 
	deleted_at VARCHAR(24), 
	trashed_at DATETIME, 
	created_at DATETIME NOT NULL, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
INSERT INTO "lists" VALUES('2116262e-e70a-4ed4-b60e-592dc28dee80','9360ff23-d715-46af-823d-fc543b91a312','Aufgaben','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:37.847904','{}',3);
INSERT INTO "lists" VALUES('24e03b85-74ec-4873-8440-41207ac6fc1e','ce988f87-4e84-46f8-81c1-1110418e8afb','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:38.890543','{}',8);
INSERT INTO "lists" VALUES('4e1e4c8a-0707-4210-b99e-de4e1d3eb38d','a98437ff-5a72-4bd7-8821-05dbe561d066','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.017621','{}',13);
INSERT INTO "lists" VALUES('74025637-ce40-4e4d-8bbe-fe488a85c418','6d00a747-c47a-4281-b0dc-10a7d2396878','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.076550','{}',16);
INSERT INTO "lists" VALUES('6a2d9cb5-c7a8-4f0c-9549-c1c873b5e5ad','b87aabcc-c609-471a-a966-8d8bafb6d22f','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.127355','{}',19);
INSERT INTO "lists" VALUES('e2d4dcbf-f40d-446c-a8d5-855509973975','84092495-6584-4899-9231-2f2cbc1d9e39','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.205456','{}',22);
INSERT INTO "lists" VALUES('dba69f72-2a8f-4e84-8ee0-77ba8078d3d6','e4419a23-9cd5-4297-ab9b-d62e224ce201','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.354760','{}',25);
INSERT INTO "lists" VALUES('0723bd74-a905-4567-bdfb-a1d04874db56','978b6c38-03fb-449a-9611-b8789531b5aa','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.413534','{}',28);
INSERT INTO "lists" VALUES('236631ee-c115-4014-9ad6-82f6b76893b6','d652daa7-223f-47fc-983f-126ad64ca2b5','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.589229','{}',31);
INSERT INTO "lists" VALUES('233fc788-4151-49eb-a309-ecc6222f4ddb','ed9abbf4-c92d-425f-bc02-d10241df8e39','Tasks','blue','list','list','a0',NULL,NULL,'2026-11-24 19:49:39.678891','{}',34);
CREATE TABLE members (
	space_id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	position VARCHAR(200), 
	joined_at DATETIME NOT NULL, 
	granted_cursor INTEGER NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (space_id, account_id), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "members" VALUES('9360ff23-d715-46af-823d-fc543b91a312',1,'manager',NULL,'2026-11-24 19:49:37.844759',2,2);
INSERT INTO "members" VALUES('d0561a4d-717b-4cc8-9008-dbd83309d638',1,'manager',NULL,'2026-11-24 19:49:37.996943',5,5);
INSERT INTO "members" VALUES('ce988f87-4e84-46f8-81c1-1110418e8afb',2,'manager',NULL,'2026-11-24 19:49:38.889990',7,7);
INSERT INTO "members" VALUES('d0561a4d-717b-4cc8-9008-dbd83309d638',2,'member',NULL,'2026-11-24 19:49:38.952371',9,9);
INSERT INTO "members" VALUES('d0561a4d-717b-4cc8-9008-dbd83309d638',3,'member',NULL,'2026-11-24 19:49:39.003554',10,10);
INSERT INTO "members" VALUES('a98437ff-5a72-4bd7-8821-05dbe561d066',3,'manager',NULL,'2026-11-24 19:49:39.016962',12,12);
INSERT INTO "members" VALUES('6d00a747-c47a-4281-b0dc-10a7d2396878',4,'manager',NULL,'2026-11-24 19:49:39.076073',15,15);
INSERT INTO "members" VALUES('b87aabcc-c609-471a-a966-8d8bafb6d22f',5,'manager',NULL,'2026-11-24 19:49:39.126812',18,18);
INSERT INTO "members" VALUES('84092495-6584-4899-9231-2f2cbc1d9e39',6,'manager',NULL,'2026-11-24 19:49:39.204795',21,21);
INSERT INTO "members" VALUES('e4419a23-9cd5-4297-ab9b-d62e224ce201',7,'manager',NULL,'2026-11-24 19:49:39.354231',24,24);
INSERT INTO "members" VALUES('978b6c38-03fb-449a-9611-b8789531b5aa',8,'manager',NULL,'2026-11-24 19:49:39.412987',27,27);
INSERT INTO "members" VALUES('d652daa7-223f-47fc-983f-126ad64ca2b5',9,'manager',NULL,'2026-11-24 19:49:39.588732',30,30);
INSERT INTO "members" VALUES('ed9abbf4-c92d-425f-bc02-d10241df8e39',10,'manager',NULL,'2026-11-24 19:49:39.678398',33,33);
CREATE TABLE notices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	kind VARCHAR(24) NOT NULL, 
	actor VARCHAR(64) NOT NULL, 
	subject VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	done_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_assigned (
	account_id INTEGER NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	at DATETIME NOT NULL, 
	by_id INTEGER, 
	PRIMARY KEY (account_id, reminder_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_channels (
	account_id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	config JSON, 
	confirmed_at DATETIME, 
	last_ok_at DATETIME, 
	last_error VARCHAR(64) NOT NULL, 
	last_error_at DATETIME, 
	PRIMARY KEY (account_id, kind), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_outbox (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	channel VARCHAR(16) NOT NULL, 
	"key" VARCHAR(120) NOT NULL, 
	payload JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	next_try_at DATETIME NOT NULL, 
	attempts INTEGER NOT NULL, 
	sent_at DATETIME, 
	failed_at DATETIME, 
	last_error VARCHAR(64) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, channel, "key"), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_routes (
	account_id INTEGER NOT NULL, 
	event VARCHAR(32) NOT NULL, 
	channel VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	PRIMARY KEY (account_id, event, channel), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_schedules (
	account_id INTEGER NOT NULL, 
	report VARCHAR(16) NOT NULL, 
	time VARCHAR(5) NOT NULL, 
	weekday INTEGER NOT NULL, 
	last_period VARCHAR(16) NOT NULL, 
	last_at DATETIME, 
	PRIMARY KEY (account_id, report), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_sent (
	account_id INTEGER NOT NULL, 
	"key" VARCHAR(80) NOT NULL, 
	sent_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id, "key"), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE oidc_links (
	id INTEGER NOT NULL, 
	provider_id INTEGER NOT NULL, 
	subject VARCHAR(255) NOT NULL, 
	account_id INTEGER NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	email VARCHAR(320), 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (provider_id, subject), 
	UNIQUE (provider_id, account_id), 
	FOREIGN KEY(provider_id) REFERENCES oidc_providers (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "oidc_links" VALUES(1,1,'bestand-fritz',7,'https://sso.example.com','fritz@example.com','2026-11-24 19:49:39.342250',NULL);
INSERT INTO "oidc_links" VALUES(2,1,'bestand-greta',8,'https://sso.example.com','greta@example.com','2026-11-24 19:49:39.538396',NULL);
CREATE TABLE oidc_providers (
	id INTEGER NOT NULL, 
	slug VARCHAR(40) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	client_id VARCHAR(255) NOT NULL, 
	client_secret_enc TEXT NOT NULL, 
	scopes VARCHAR(500) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	auto_create BOOLEAN NOT NULL, 
	trusts_second_factor BOOLEAN NOT NULL, 
	managed VARCHAR(20) NOT NULL, 
	position INTEGER NOT NULL, 
	redirect_path VARCHAR(300) NOT NULL, 
	registered_redirect VARCHAR(500) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (slug)
);
INSERT INTO "oidc_providers" VALUES(1,'sso','SSO','https://sso.example.com','nextasks-bestand','6a685a44ba30800a7c092eb665adce71fdf06643f4e4b68e91caeaae18e1ad9bef025f6af881cab10326','openid profile email',1,1,1,'',0,'','','2026-11-24 19:49:38.758055');
CREATE TABLE page_cursors (
	account_id INTEGER NOT NULL, 
	cursor INTEGER NOT NULL, 
	issued_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id, cursor), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE reminders (
	id VARCHAR(36) NOT NULL, 
	list_id VARCHAR(36) NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	section_id VARCHAR(36), 
	parent_id VARCHAR(36), 
	position VARCHAR(200) NOT NULL, 
	title VARCHAR(500) NOT NULL, 
	notes TEXT NOT NULL, 
	url VARCHAR(2000), 
	due_date VARCHAR(10), 
	due_time VARCHAR(5), 
	repeat VARCHAR(200), 
	repeat_from VARCHAR(16) NOT NULL, 
	location JSON, 
	flagged BOOLEAN NOT NULL, 
	priority INTEGER NOT NULL, 
	tags JSON NOT NULL, 
	assignees JSON NOT NULL, 
	rotation JSON, 
	completed_at VARCHAR(24), 
	completed_by INTEGER, 
	created_by INTEGER, 
	created_at VARCHAR(24) NOT NULL, 
	deleted_at VARCHAR(24), 
	trashed_at DATETIME, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(list_id) REFERENCES lists (id) ON DELETE CASCADE
);
CREATE TABLE sections (
	id VARCHAR(36) NOT NULL, 
	list_id VARCHAR(36) NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	position VARCHAR(200) NOT NULL, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(list_id) REFERENCES lists (id) ON DELETE CASCADE
);
CREATE TABLE settings (
	"key" VARCHAR(64) NOT NULL, 
	value JSON, 
	PRIMARY KEY ("key")
);
INSERT INTO "settings" VALUES('completions_filled','true');
INSERT INTO "settings" VALUES('api_tokens_allowed','true');
INSERT INTO "settings" VALUES('smtp_host','""');
INSERT INTO "settings" VALUES('smtp_from','""');
INSERT INTO "settings" VALUES('public_url','"https://tasks.example.com"');
CREATE TABLE space_prefs (
	account_id INTEGER NOT NULL, 
	space_id VARCHAR(36) NOT NULL, 
	hidden BOOLEAN NOT NULL, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (account_id, space_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
CREATE TABLE spaces (
	id VARCHAR(36) NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	color VARCHAR(16) NOT NULL, 
	icon VARCHAR(64) NOT NULL, 
	private BOOLEAN NOT NULL, 
	owner_id INTEGER, 
	deleted_at VARCHAR(24), 
	trashed_at DATETIME, 
	orphaned_at DATETIME, 
	created_at DATETIME NOT NULL, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "spaces" VALUES('9360ff23-d715-46af-823d-fc543b91a312','Privat','blue','list',1,1,NULL,NULL,NULL,'2026-11-24 19:49:37.833252','{}',1);
INSERT INTO "spaces" VALUES('d0561a4d-717b-4cc8-9008-dbd83309d638','Familie','blue','list',0,NULL,NULL,NULL,NULL,'2026-11-24 19:49:37.989543','{}',4);
INSERT INTO "spaces" VALUES('ce988f87-4e84-46f8-81c1-1110418e8afb','Private','blue','list',1,2,NULL,NULL,NULL,'2026-11-24 19:49:38.887093','{}',6);
INSERT INTO "spaces" VALUES('a98437ff-5a72-4bd7-8821-05dbe561d066','Private','blue','list',1,3,NULL,NULL,NULL,'2026-11-24 19:49:39.014069','{}',11);
INSERT INTO "spaces" VALUES('6d00a747-c47a-4281-b0dc-10a7d2396878','Private','blue','list',1,4,NULL,NULL,NULL,'2026-11-24 19:49:39.073474','{}',14);
INSERT INTO "spaces" VALUES('b87aabcc-c609-471a-a966-8d8bafb6d22f','Private','blue','list',1,5,NULL,NULL,NULL,'2026-11-24 19:49:39.123782','{}',17);
INSERT INTO "spaces" VALUES('84092495-6584-4899-9231-2f2cbc1d9e39','Private','blue','list',1,6,NULL,NULL,NULL,'2026-11-24 19:49:39.202098','{}',20);
INSERT INTO "spaces" VALUES('e4419a23-9cd5-4297-ab9b-d62e224ce201','Private','blue','list',1,7,NULL,NULL,NULL,'2026-11-24 19:49:39.351128','{}',23);
INSERT INTO "spaces" VALUES('978b6c38-03fb-449a-9611-b8789531b5aa','Private','blue','list',1,8,NULL,NULL,NULL,'2026-11-24 19:49:39.410101','{}',26);
INSERT INTO "spaces" VALUES('d652daa7-223f-47fc-983f-126ad64ca2b5','Private','blue','list',1,9,NULL,NULL,NULL,'2026-11-24 19:49:39.586136','{}',29);
INSERT INTO "spaces" VALUES('ed9abbf4-c92d-425f-bc02-d10241df8e39','Private','blue','list',1,10,NULL,NULL,NULL,'2026-11-24 19:49:39.675750','{}',32);
CREATE TABLE sweep_keeps (
	account_id INTEGER NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	until DATETIME NOT NULL, 
	PRIMARY KEY (account_id, reminder_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE sync_state (
	id INTEGER NOT NULL, 
	last INTEGER NOT NULL, 
	oldest INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "sync_state" VALUES(1,39,0);
CREATE TABLE task_events (
	id INTEGER NOT NULL, 
	reminder_id VARCHAR(36) NOT NULL, 
	actor_id INTEGER, 
	field VARCHAR(16) NOT NULL, 
	old JSON, 
	new JSON, 
	first_at DATETIME NOT NULL, 
	at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(reminder_id) REFERENCES reminders (id) ON DELETE CASCADE
);
CREATE TABLE tile_prefs (
	account_id INTEGER NOT NULL, 
	tile_id VARCHAR(36) NOT NULL, 
	hidden BOOLEAN NOT NULL, 
	clock JSON NOT NULL, 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (account_id, tile_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE webpush_subscriptions (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	endpoint VARCHAR(1000) NOT NULL, 
	p256dh VARCHAR(200) NOT NULL, 
	auth VARCHAR(100) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_ok_at DATETIME, 
	user_agent VARCHAR(300) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (endpoint)
);
CREATE INDEX ix_app_ops_created_at ON app_ops (created_at);
CREATE INDEX ix_gone_space_id ON gone (space_id);
CREATE INDEX ix_gone_cursor ON gone (cursor);
CREATE INDEX ix_cursor_times_at ON cursor_times (at);
CREATE INDEX ix_completions_list_id ON completions (list_id);
CREATE INDEX ix_completions_series_id ON completions (series_id);
CREATE INDEX ix_completions_completed_at ON completions (completed_at);
CREATE INDEX ix_completions_space_id ON completions (space_id);
CREATE INDEX ix_auth_sessions_account_id ON auth_sessions (account_id);
CREATE INDEX ix_oidc_links_provider_id ON oidc_links (provider_id);
CREATE INDEX ix_oidc_links_account_id ON oidc_links (account_id);
CREATE INDEX ix_api_tokens_account_id ON api_tokens (account_id);
CREATE INDEX ix_app_pairings_account_id ON app_pairings (account_id);
CREATE INDEX ix_app_pairings_code_hash ON app_pairings (code_hash);
CREATE INDEX ix_app_devices_account_id ON app_devices (account_id);
CREATE INDEX ix_webpush_subscriptions_account_id ON webpush_subscriptions (account_id);
CREATE INDEX ix_page_cursors_issued_at ON page_cursors (issued_at);
CREATE INDEX ix_spaces_cursor ON spaces (cursor);
CREATE INDEX ix_spaces_owner_id ON spaces (owner_id);
CREATE INDEX ix_filters_cursor ON filters (cursor);
CREATE INDEX ix_filters_account_id ON filters (account_id);
CREATE INDEX ix_tile_prefs_cursor ON tile_prefs (cursor);
CREATE INDEX hidden_account_cursor ON hidden (account_id, cursor);
CREATE INDEX ix_hidden_cursor ON hidden (cursor);
CREATE INDEX ix_notices_account_id ON notices (account_id);
CREATE INDEX ix_notify_sent_sent_at ON notify_sent (sent_at);
CREATE INDEX ix_change_bundles_opened_at ON change_bundles (opened_at);
CREATE INDEX ix_comment_bundles_opened_at ON comment_bundles (opened_at);
CREATE INDEX ix_notify_outbox_next_try_at ON notify_outbox (next_try_at);
CREATE INDEX ix_notify_outbox_account_id ON notify_outbox (account_id);
CREATE INDEX ix_notify_outbox_created_at ON notify_outbox (created_at);
CREATE INDEX ix_notify_assigned_at ON notify_assigned (at);
CREATE INDEX ix_members_account_id ON members (account_id);
CREATE INDEX ix_members_cursor ON members (cursor);
CREATE INDEX ix_lists_space_id ON lists (space_id);
CREATE INDEX ix_lists_cursor ON lists (cursor);
CREATE INDEX ix_space_prefs_cursor ON space_prefs (cursor);
CREATE INDEX ix_space_prefs_space_id ON space_prefs (space_id);
CREATE INDEX ix_invites_space_id ON invites (space_id);
CREATE INDEX ix_sections_space_id ON sections (space_id);
CREATE INDEX ix_sections_list_id ON sections (list_id);
CREATE INDEX ix_sections_cursor ON sections (cursor);
CREATE INDEX ix_reminders_cursor ON reminders (cursor);
CREATE INDEX ix_reminders_parent_id ON reminders (parent_id);
CREATE INDEX ix_reminders_list_id ON reminders (list_id);
CREATE INDEX reminders_due ON reminders (due_date, due_time);
CREATE INDEX ix_reminders_space_id ON reminders (space_id);
CREATE INDEX ix_list_prefs_list_id ON list_prefs (list_id);
CREATE INDEX ix_list_prefs_space_id ON list_prefs (space_id);
CREATE INDEX ix_list_prefs_cursor ON list_prefs (cursor);
CREATE INDEX ix_attachments_hash ON attachments (hash);
CREATE INDEX ix_attachments_reminder_id ON attachments (reminder_id);
CREATE INDEX ix_attachments_space_id ON attachments (space_id);
CREATE INDEX ix_attachments_cursor ON attachments (cursor);
CREATE INDEX ix_comments_space_id ON comments (space_id);
CREATE INDEX ix_comments_reminder_id ON comments (reminder_id);
CREATE INDEX ix_comments_cursor ON comments (cursor);
CREATE INDEX ix_task_events_at ON task_events (at);
CREATE INDEX ix_task_events_reminder_id ON task_events (reminder_id);
CREATE INDEX ix_external_refs_reminder_id ON external_refs (reminder_id);
COMMIT;
